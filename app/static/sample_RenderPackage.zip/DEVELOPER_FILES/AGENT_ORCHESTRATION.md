# Agent Orchestration

This RenderPackage has already been generated.

An agent should not recreate the package.
An agent should consume this package as a workflow contract for downstream AI-video generation.

## Source of truth

Use:

DEVELOPER_FILES/rpack.json

as the machine-readable source of truth.

Use creator-facing files only for human review.

## Agent workflow

1. Read DEVELOPER_FILES/rpack.json
2. Load the scene metadata
3. Load the shot list
4. For each shot, read:
   - shot ID
   - shot intent
   - base prompt
   - required references
   - suggested framing
   - post-production notes where available
5. Check whether required reference folders contain user-provided assets
6. If references are missing, ask the user to add them or use a separate image-generation workflow
7. Ask the user which AI video provider or local workflow to use
8. Map the shot data to a provider-specific adapter
9. Prepare generation requests using:
   - base prompt
   - selected references
   - provider settings
   - shot ID
10. Submit generation jobs only when the user has configured provider access
11. Poll or monitor generation jobs if the provider supports it
12. Save generated takes using shot IDs
13. Preserve provider settings and provenance
14. Let the creator choose keepers, or assist with keeper review if explicitly supported
15. Update keeper/provenance outputs

## Boundaries

The agent must not assume:
- provider API access exists
- provider capabilities are available
- references will be accepted by every tool
- output will be deterministic
- lip-sync will be accurate
- exact duration will be obeyed
- the first generation will be usable

## Human-in-the-loop rule

The creator remains responsible for:
- creative judgment
- prompt tuning
- selecting keepers
- editing
- final dialogue/audio
- post-production polish

## File handling

Generated takes should be saved using shot IDs.

Preferred naming:

shot_001_take_01.mp4
shot_001_take_02.mp4
shot_001_keeper.mp4

Use the package folders:

generated_shots/takes/
generated_shots/keepers/

If an agent creates per-shot subfolders, keep them under generated_shots/takes/.

Do not place generated media inside DEVELOPER_FILES.

## Provider adapters

Provider adapters should translate RenderPackage data into provider-specific requests.

Adapters may use:
- base prompts
- reference folders
- shot metadata
- duration/editing targets
- provider capability maps

Adapters must not claim:
- deterministic output
- guaranteed continuity
- guaranteed lip-sync
- finished-film quality

## Safety and provenance

Agents should preserve:
- shot ID
- prompt text used
- reference assets used
- provider name
- provider settings
- generation timestamp
- output filename
- user keeper choice where available
