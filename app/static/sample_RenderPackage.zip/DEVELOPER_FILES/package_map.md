# RenderPackage Map

## Creator-facing files

- `RENDERPACKAGE.pdf`: main storyboard-led shooting pack.
- `COPY_PASTE_PROMPTS.docx`: portable copy/paste prompts.
- `KEEPER_SHEET.csv`: minimal keeper tracking sheet.

- The source `.fountain` screenplay is included at the package root for reference.

## Generated shot folders

- `generated_shots/takes/`: suggested place to save generated test takes.
- `generated_shots/keepers/`: suggested place to save selected keeper clips.

## Reference folders

- Human-readable folders under `refs/` are generated automatically for style, location, characters, and props.
- Creators manually attach or upload those images in their AI video tool.

## Developer files

- Machine-readable source of truth: `DEVELOPER_FILES/rpack.json`.
- Build/provenance metadata: `DEVELOPER_FILES/provenance.json`.
- Shot list: `DEVELOPER_FILES/shot_list.csv`.
- Reference bindings: `DEVELOPER_FILES/bindings.csv`.
- Prompt packs: `DEVELOPER_FILES/prompt_packs/`.
- This package uses the Universal workflow.
- Selected prompt profile: `DEVELOPER_FILES/prompt_packs/shot_prompts.md`.
- Add optional provider prompt packs when you want tool-specific prompt formatting.

## Agent orchestration

- `DEVELOPER_FILES/AGENT_ORCHESTRATION.md` explains how external/local agents can consume this package.
- `DEVELOPER_FILES/provider_capabilities.example.json` is a template for describing provider adapter capabilities.
- `DEVELOPER_FILES/rpack.json` remains the machine-readable source of truth.
- Agents should use the package after it is generated; they should not recreate the RenderPackage.

Creator workflow does not depend on opening this folder.
