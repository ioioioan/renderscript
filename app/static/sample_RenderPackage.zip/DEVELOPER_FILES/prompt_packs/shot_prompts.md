# Universal RenderPackage Prompts

IMPORTANT: NO ON-SCREEN TEXT. NO SUBTITLES. NO CAPTIONS. NO WATERMARKS. NO LOGOS.
Generate picture-only shots. Audio/dialogue will be added in post.

> Drift warning: outputs can still vary; review each shot for continuity.

## shot_001 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=none, location=loc_01_ref_01, style=style_01_ref_01
Prompt: A kettle clicks off on the stove. Framing wide. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_002 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_M_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Props references: prop_01_ref_01, prop_02_ref_01
Prompt: Maya folds a city map and slides it into a canvas tote. Framing medium. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_003 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_J_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Props references: prop_03_ref_01
Prompt: Jonah checks his watch near the doorway. Framing close. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_004 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_M_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Prompt: Maya asks, "Did you print the permit form?". Framing wide. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_005 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_J_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Prompt: Reaction on Jonah as Maya asks, "Did you print the permit form?". Framing medium. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_006 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_M_ref_01, char_J_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Prompt: Two-shot coverage holds Maya and Jonah as the permit question lands. Framing close. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_007 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_J_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Prompt: Jonah answers, "It's in the blue folder," with a quick practical response. Framing wide. Stay in this location. Do not invent new characters or props. Keep consistent look.

## shot_008 (3s)

No on-screen text or subtitles.
Apply references: Attach style/location/character reference images if your tool supports them.
Required ref IDs: character=char_M_ref_01, location=loc_01_ref_01, style=style_01_ref_01
Prompt: Maya says Good. Grab the tape measure too. Framing medium. Stay in this location. Do not invent new characters or props. Keep consistent look.
