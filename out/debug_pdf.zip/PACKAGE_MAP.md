Start here: CREATOR_GUIDE(Start here).pdf

- Package profile: `universal`.
- If you want broad compatibility: universal package works with tool-agnostic prompts.
- If you want Runway-specific reference steps: runway package includes them.
- If you want a fast creator walkthrough: open `CREATOR_GUIDE(Start here).pdf`.
- If you want shot-by-shot prompts: open `prompts/shot_prompts.md`.
- If you want the required references list: open `assets/ingredients_manifest.md`.
- If you want prompts to generate reference images: open `prompts/asset_prompts.md`.
- If you want placeholder folders for assets: open `assets/placeholder/`.
- If you want character voice guidance: open `audio/voice_bible.md`.
- If you want dialogue lines for post audio: open `audio/dialogue_script.txt`.
- If you want per-shot ambience/SFX cues: open `audio/sfx_cue_sheet.md`.
- If you want optional external subtitles for editing: open `edit/subtitles.srt`.
- If you want durations and framing per shot: open `shots/shot_list.csv`.
- If you want the Reference Map per shot: open `bindings/bindings.csv`.
- If you want scoring and keeper tracking: open `rubric/scoring_sheet.csv`.
- If you want machine-readable package details: open `rpack.json`.
- If you want developer/operator instructions: open `README.md`.
