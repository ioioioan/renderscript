# How to run this RenderPackage in Runway Gen-4 Image References

This package is prepared for `runway.gen4_image_refs` workflows.

## Steps

1. Open Runway and start a Gen-4 image generation workflow.
2. Enable **References**.
3. Add references for the current shot (maximum 3 active at a time in Runway).
4. Read required references in `bindings/bindings.csv` for that shot.
5. Paste the matching prompt from `prompts/runway.gen4_image_refs_prompts.md`.
6. Set the shot duration from `shots/shot_list.csv`.
7. Generate output, then score it in `rubric/scoring_sheet.csv`.
8. Reroll as needed while keeping reference IDs and prompt intent unchanged.

## Limits & drift warnings

- Results are not deterministic, even with fixed prompts and references.
- Reference quality and consistency still depend on source image quality.
- Runway supports up to 3 active references per generation.
- Identity, wardrobe, and location drift can still occur and may require rerolls.
- Overly broad prompt edits can reduce visual continuity across shots.
