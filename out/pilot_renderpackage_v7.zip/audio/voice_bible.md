# Voice Bible

Audio post guidance only. Avoid personal likeness or impersonation.

## ALICE
- Tone: grounded and clear
- Pace: medium
- Energy: natural, controlled
- Likeness: no real-person mimicry

## BOB
- Tone: grounded and clear
- Pace: medium
- Energy: natural, controlled
- Likeness: no real-person mimicry
