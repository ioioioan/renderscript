# RenderPackage Map

## 1) What to open first

- Start with `CREATOR_GUIDE.pdf`.
- Then follow `START_HERE.txt` for the quick flow.

## 2) Where references go

- Place all reference images inside `assets/refs/`.
- Use `assets/ingredients_manifest.md` for required IDs and naming.

## 3) Where prompts live

- Universal shot prompts: `prompts/shot_prompts.md`.
- Provider-specific prompts: `prompts/<provider>_prompts.md`.
- This package uses the Universal workflow.
- Use `prompts/shot_prompts.md` to generate shots.
- Reference image prompt helper: `prompts/asset_prompts.md`.

## 4) Where to track keepers

- Directing sheet: `shots/shot_list.csv`.
- Reference map: `shots/bindings.csv`.
- Keeper tracking sheet: `keepers/scoring_sheet.csv`.

## 5) Where audio files live

- Dialogue script: `audio/dialogue_script.txt`.
- Voice guide: `audio/voice_bible.md`.
- SFX cues: `audio/sfx_cue_sheet.md`.
- Optional subtitle guide: `edit_guide/subtitles.srt`.

## 6) Developer files

- Machine-readable source of truth: `dev/rpack.json`.
- Build/provenance metadata: `dev/provenance.json`.
